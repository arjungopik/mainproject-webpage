function toggleCollapsibleText(container) {
    const collapsibleText = container.querySelector('.colapsible-text');
    collapsibleText.classList.toggle('visible');
    container.classList.toggle('centered');
  }
  